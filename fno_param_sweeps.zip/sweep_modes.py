# Auto-generated parameter sweep for modes
from fno_core import run_binary_search

sweep_settings = {
    'modes': [4, 8, 12, 16, 20, 24, 28, 32]
}

run_binary_search(
    param_name='modes',
    param_values=sweep_settings['modes'],
    tolerance=1,
    grid_size=32
)
