# Auto-generated parameter sweep for width
from fno_core import run_binary_search

sweep_settings = {
    'width': [16, 32, 48, 64, 80, 96, 112, 128]
}

run_binary_search(
    param_name='width',
    param_values=sweep_settings['width'],
    tolerance=1,
    grid_size=32
)
