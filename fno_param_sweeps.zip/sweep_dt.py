# Auto-generated parameter sweep for dt
from fno_core import run_binary_search

sweep_settings = {
    'dt': [0.001, 0.005, 0.01, 0.02, 0.04]
}

run_binary_search(
    param_name='dt',
    param_values=sweep_settings['dt'],
    tolerance=0.05,
    grid_size=32
)
