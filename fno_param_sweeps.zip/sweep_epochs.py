# Auto-generated parameter sweep for epochs
from fno_core import run_binary_search

sweep_settings = {
    'epochs': [50, 100, 150, 200, 250, 300, 350, 400, 450, 500]
}

run_binary_search(
    param_name='epochs',
    param_values=sweep_settings['epochs'],
    tolerance=1,
    grid_size=32
)
