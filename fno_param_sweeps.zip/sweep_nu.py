# Auto-generated parameter sweep for nu
from fno_core import run_binary_search

sweep_settings = {
    'nu': [0.0001, 0.0005, 0.001, 0.002, 0.005]
}

run_binary_search(
    param_name='nu',
    param_values=sweep_settings['nu'],
    tolerance=0.0005,
    grid_size=32
)
