# Auto-generated parameter sweep for batch_size
from fno_core import run_binary_search

sweep_settings = {
    'batch_size': [4, 8, 12, 16, 20, 24, 28, 32]
}

run_binary_search(
    param_name='batch_size',
    param_values=sweep_settings['batch_size'],
    tolerance=1,
    grid_size=32
)
